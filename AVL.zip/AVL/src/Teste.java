////Carlos L. Santos, Maria Luiza M. Silva, Victor A. Felix Teixeira

import java.util.Scanner;

public class Teste {
	
	public static void main(String args[]){
        Scanner teclado = new Scanner(System.in);
        
        int[] coisa = {2,9,78,5,12,6,67,4,76,7,8,34,77,11,33,15,13,25,93,45,56,37,81,341,66,70,32,97,80,10};
        
        ArvoreAVL arvore = new ArvoreAVL();
        
        for(int i=0;i<coisa.length;i++)
        {
        	 arvore = arvore.inserir(new Elemento(coisa[i]));
             arvore.calcularBalanceamento();
             arvore = arvore.verificaBalanceamento();
            
        	 
        }
        
        System.out.println(arvore.printArvore(0));
        System.out.println(arvore.busca(341)+" n busca:"+arvore.buscaCon(341,0));
        
       
    }
	
	

}
